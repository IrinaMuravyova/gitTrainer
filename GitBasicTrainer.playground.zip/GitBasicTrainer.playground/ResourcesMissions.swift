
// MARK: - Миссии "Новичок"
// MARK: - Новичок Блок 1. Создаем и наводим порядок в проекте
let mission1 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 1. «Создаём структуру проекта»",
        description: "Что получим:\nСтруктуру проекта из трёх папок, умение переходить между уровнями и просматривать их содержимое.",
        steps: [
            "Создай папку для нового проекта",
            "Внутри создай подпапки src, docs и assets",
            "Зайди в каждую и посмотри содержимое",
            "Вернись в корневую директорию проекта",
            "Проверь, какие папки ты создал"
        ],
        completed: [false, false, false, false, false],
        cheatSheetCommands: ["pwd", "mkdir", "cd", "ls", "cd_upin", "cd_up"]
    )

let mission2 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 2. «Навигация по папкам»",
    description: "Что получим:\nНавык уверенного перемещения по структуре проекта и системы.",
    steps: [
        "Посмотри текущий путь",
        "Перейди в одну из подпапок проекта",
        "Вернись на два уровня выше",
        "Перейди сразу в домашнюю директорию",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["pwd", "cd", "cd_up2","cd_home"]
)

let mission3 = Mission(
taskType: TaskType.createAndStructure,
    title: "Квест 3. «Организуем файлы»",
    description: "Что получим:\nУверенное владение базовыми командами создания и удаления файлов.",
    steps: [
        "Создай в проекте три файла с разными именами",
        "Проверь, что они появились",
        "Удали один из них",
        "Снова проверь список файлов",
        "Посмотри историю своих действий"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "ls", "rm", "history"]
)

let mission4 = Mission(
taskType: TaskType.createAndStructure,
    title: "Квест 4. «Переименование проекта»",
    description: "Что получим:\nНавык переименования директорий и перемещения к ним.",
    steps: [
        "Посмотри список папок",
        "Переименуй основную папку проекта",
        "Проверь, что новое имя применилось",
        "Перейди в переименованную папку",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mv", "mv_rename", "ls_d", "cd", "clear"]
)

let mission5 = Mission(
taskType: TaskType.createAndStructure,
    title: "Квест 5. «Удаляем старый проект»",
    description: "Что получим:\nНавык безопасного удаления проектов.",
    steps: [
        "Посмотри список папок в текущей директории",
        "Найди ненужный проект",
        "Удали его целиком",
        "Убедись, что он исчез",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["ls_d","rm_r", "clear"]
)
    
// MARK: - Новичок Блок 2. Работа с файлами и содержимым
let mission6 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 1. «Создаём заметки»",
    description: "Что получим:\nНавык создания и редактирования текстовых файлов через терминал.",
    steps: [
        "Создай новый файл для заметок",
        "Добавь в него три строки текста",
        "Просмотри содержимое",
        "Добавь ещё одну строку",
        "Снова выведи весь текст"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo", "cat", "echo_append"]
)

let mission7 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 2. «Сравнение файлов»",
    description: "Что получим:\nНавык копирования и проверки изменений в файлах.",
    steps: [
        "Создай два текстовых файла",
        "Добавь разные строки в каждый",
        "Посмотри содержимое обоих",
        "Скопируй один файл в другой",
        "Проверь результат"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo", "cat", "cp"]
)

let mission8 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 3. «Мини-отчёт»",
    description: "Что получим:\nПонимание работы команд head и tail.",
    steps: [
        "Создай файл report.txt",
        "Добавь в него три строки отчёта",
        "Покажи только первые две строки",
        "Покажи последнюю строку",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo", "echo_append", "head_n", "tail_n", "clear"]
)

let mission9 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 4. «Перемещение файлов»",
    description: "Что получим:\nНавык перемещения файлов между папками.",
    steps: [
        "Создай две папки: projectA и projectB",
        "Добавь файл в первую",
        "Перемести его во вторую",
        "Убедись, что он переместился",
        "Посмотри историю действий"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "touch_in_dir", "mv_from_dir", "ls", "history"]
)

let mission10 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 5. «Создание резервной копии»",
    description: "Что получим:\nНавык быстрого резервного копирования.",
    steps: [
        "Создай важный файл",
        "Добавь туда текст",
        "Скопируй его с новым именем, добавив слово backup",
        "Проверь оба файла",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["echo", "touch", "cp", "ls", "clear"]
)

//MARK: - Новичок Блок 3. Диагностика, история и “разработческая чистка”
let mission11 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 1. «Проверяем окружение»",
    description: "Что получим:\nНавык ориентации в файловой системе.",
    steps: [
        "Посмотри, где находишься",
        "Узнай, какие файлы рядом",
        "Создай папку и перейди в неё",
        "Посмотри текущий путь",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["pwd", "ls", "mkdir", "cd", "clear"]
)

let mission12 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 2. «Сохраняем список файлов»",
    description: "Что получим:\nНавык перенаправления вывода в файл и удаления объектов.",
    steps: [
        "Создай папку и несколько файлов в ней",
        "Сохрани список этих файлов в отдельный документ",
        "Просмотри содержимое созданного документа",
        "Удали один файл",
        "Проверь, что он действительно удалён"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "cd", "touch", "ls_save", "cat", "rm", "ls"]
)

let mission13 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 3. «Удаляем мусор»",
    description: "Что получим:\nУверенность при использовании rm -r и rm -rf.",
    steps: [
        "Создай временную папку",
        "Добавь туда несколько файлов",
        "Удали папку целиком",
        "Проверь, осталась ли она",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "touch_some", "rm -rf", "ls", "clear"]
)

let mission14 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 4. «Поиск нужной команды»",
    description: "Что получим:\nУмение работать со встроенной документацией.",
    steps: [
        "Открой справку по команде ls",
        "Посмотри какие у неё есть параметры",
        "Закрой справку",
        "Очисти экран",
        "Посмотри историю последних действий"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["man", "clear", "history"]
)

let mission15 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 5. «Управляем процессами»",
    description: "Что получим:\nПонимание сочетаний клавиш и управления вводом.",
    steps: [
        "Запусти рекурсивный список всех файлов с корня",
        "Останови её выполнение",
        "Перейди в начало строки",
        "Перейди в конец строки",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["ls_R", "сontrol_C", "сontrol_A", "сontrol_E", "clear"]
)

// MARK: - Миссии "Продвинутый"
// MARK: - Продвинутый Блок 1. Создаем и наводим порядок в проекте

let mission16 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 1. «Подготовка репозитория»",
    description: "Что получим:\nОрганизованную структуру веб-проекта и навык изменения иерархии.",
    steps: [
        "Создай папку portfolio-website",
        "Внутри сделай три подпапки: src, images, backup",
        "Перейди в src и создай там файлы index.html и style.css",
        "Вернись в корень проекта",
        "Удали папку backup и создай новую assets вместо неё"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "cd", "touch", "touch_some", "cd_up", "rm_r"]
)


let mission17 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 2. «Структура для нескольких версий»",
    description: "Что получим:\nПонимание копирования между папками и структурой версий.",
    steps: [
        "Создай папку myApp",
        "Внутри сделай две версии: v1.0 и v2.0",
        "Добавь файл readme.txt в каждую версию",
        "Скопируй содержимое из v1.0 в v2.0",
        "Проверь, что файлы совпадают"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "cd", "touch", "touch_some", "cp_dir", "cp_files_in_dir", "diff"]
)

let mission18 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 3. «Навигация в глубине»",
    description: "Что получим:\nНавык работы с длинными путями.",
    steps: [
        "Создай вложенную структуру projects/code/ios/demo",
        "Перейди сразу в demo одной командой",
        "Проверь путь, где находишься",
        "Вернись обратно в корень проекта",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir_multiple", "cd", "pwd", "cd_in_some", "cd_up_some", "clear"]
)

let mission19 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 4. «Чистим старые черновики»",
    description: "Что получим:\nНавык выборочного удаления и переименования.",
    steps: [
        "Создай папку drafts и добавь в неё 3 файла: idea1.txt, idea2.txt, idea3.txt",
        "Удали все файлы, кроме idea2.txt",
        "Переименуй оставшийся файл в final_idea.txt",
        "Посмотри список файлов",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "touch_some", "rm", "mv_rename", "ls", "clear"]
)

let mission20 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 5. «Архитектура продукта»",
    description: "Что получим:\nСтруктурный подход и понимание работы с несколькими уровнями папок.",
    steps: [
        "Создай папку game-project",
        "Внутри создай code, design, docs",
        "В docs создай readme.txt и changelog.txt",
        "Скопируй оба файла в папку code для теста",
        "Удали папку design"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "cd", "touch", "cp", "rm_r", "rm_dir", "cp_files_in_dir"]
)

// MARK: - Продвинутый Блок 2. Работа с файлами и содержимым
let mission21 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 1. «Создаём лог изменений»",
    description: "Что получим:\nНавык создания и чтения логов, копирования и работы с последними строками файла.",
    steps: [
        "Создай файл changelog.txt",
        "Добавь туда строки с датами изменений (например, 2025-10-11 Added login screen)",
        "Выведи только последние строки изменений",
        "Сохрани копию файла под именем changelog_backup.txt",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo_append", "tail_n", "echo >>", "cp", "clear"]
)

let mission22 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 2. «Объединение контента»",
    description: "Что получим:\nНавык объединения файлов.",
    steps: [
        "Создай три файла: part1.txt, part2.txt, part3.txt",
        "Добавь в каждый по одной строке текста",
        "Объедини их содержимое в один файл all_parts.txt",
        "Проверь результат",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "touch_some", "echo", "cat", "cat_join", "clear"]
)

let mission23 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 3. «Автоматическая подпись»",
    description: "Что получим:\nУмение дополнять файлы и работать с поддиректориями.",
    steps: [
        "Создай файл message.txt с текстом “Hello from terminal”",
        "Добавь строку “— Sent via CLI bot” в конец файла",
        "Проверь, что подпись добавилась",
        "Скопируй файл в папку outbox",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch","echo", "echo_append", "cat", "mkdir", "cp", "clear"]
)

let mission24 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 4. «Журнал задач»",
    description: "Что получим:\nПонимание резервного копирования и переименования.",
    steps: [
        "Создай файл tasks.txt",
        "Добавь туда 5 задач с нумерацией",
        "Выведи только первые 3 строки",
        "Создай резервную копию tasks_backup.txt",
        "Переименуй оригинал в tasks_today.txt"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo", "echo_append", "head_n", "cp", "mv_rename"]
)

let mission25 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 5. «История изменений проекта»",
    description: "Что получим:\nПрактику на вывод строк и удаление.",
    steps: [
        "Создай файл update_log.txt",
        "Добавь три обновления по дате",
        "Выведи первые и последние строки для проверки",
        "Удали файл после проверки",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["touch", "echo", "echo_append", "head_n", "head", "tail", "tail_n", "rm", "clear"]
)

//MARK: - Продвинутый Блок 3. Диагностика, история и “разработческая чистка”
let mission26 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 1. «Создание отчёта об окружении»",
    description: "Что получим:\nНавык перенаправления вывода и добавления данных.",
    steps: [
        "Посмотри, где находишься",
        "Сохрани результат команды, показывающей текущие файлы, в документ environment.txt",
        "Добавь в него дату и подпись “checked”",
        "Проверь содержимое",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["pwd", "ls_save", "echo_append", "cat", "clear"]
)

let mission27 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 2. «Архивация проекта»",
    description: "Что получим:\nНавык копирования и безопасного удаления старых данных.",
    steps: [
        "Создай папку project-archive",
        "Добавь туда пару файлов (log.txt, old_version.txt)",
        "Скопируй эти файлы в новую папку backup-2025",
        "Удали оригинальные файлы",
        "Проверь, что копии сохранились"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "touch", "touch_some", "cp", "cp_files_in_dir", "rm", "rm_files", "ls"]
)

let mission28 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 3. «Чистим DerivedData вручную»",
    description: "Что получим:\nУверенность в работе с системными путями и безопасным использованием rm.",
    steps: [
        "Перейди в домашнюю директорию",
        "Проверь, существует ли путь ~/Library/Developer/Xcode/DerivedData",
        "Если есть, удали его целиком",
        "Проверь, что он исчез",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["cd_home", "ls_path", "rm_path", "rm_dir", "clear"]
)

let mission29 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 4. «Анализ истории команд»",
    description: "Что получим:\nНавык повторного вызова команд из истории.",
    steps: [
        "Введи несколько простых команд (ls, pwd, mkdir temp)",
        "Посмотри историю",
        "Найди номер команды mkdir",
        "Повтори эту команду через !<номер>",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["ls", "pwd", "mkdir", "print_com_number", "repeat_com", "clear", "history"]
)

let mission30 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 5. «Тестируем аварийное завершение»",
    description: "Что получим:\nПонимание управления процессами и горячих клавиш.",
    steps: [
        "Запусти бесконечный вывод (например, yes test)",
        "Прерви процесс",
        "Перейди в начало и конец строки",
        "Очисти экран",
        "Проверь историю команд"
    ],
    completed: [false, false, false, false, false],
    cheatSheetCommands: ["control_C", "control_A", "control_E", "clear", "yes", "history"]
)

// MARK: - Миссии "Профи"
// MARK: - Профи Блок 1. Создаем и наводим порядок в проекте

let mission31 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 1. «Создание и инициализация проекта Xcode с нуля»",
    description: "Что получим:\nСтруктурированный шаблон проекта под Xcode с базовой иерархией каталогов, файлами-заглушками и конфигурационным файлом.",
    steps: [
        "Определи, где ты находишься",
        "Создай папку WeatherTracker",
        "Внутри — подпапки: Sources, Assets, Tests, Scripts",
        "Перейди в Sources и создай AppDelegate.swift, SceneDelegate.swift, ContentView.swift",
        "Вернись на уровень выше",
        "В Assets создай папки Icons, Images, Sounds",
        "Добавь туда по одному файлу-заглушке через touch",
        "Вернись в корень проекта",
        "Создай скрытую папку .config и файл env.local",
        "Добавь туда строку API_KEY=”1234-TEST-KEY”",
        "Вернись в корень и создай README.md",
        "Добавь туда строку “WeatherTracker — iOS demo project”",
        "Проверь, что все файлы и папки созданы",
        "Сохрани список файлов в structure.txt",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["pwd", "mkdir", "mkdir_multiple", "cd", "touch_some", "cd_up", "touch_in_dir", "echo", "touch", "ls_R", "redirect", "clear", "man"]
)


let mission32 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 2. «Добавляем модуль Networking и его тесты»",
    description: "Что получим:\nПроект с модулем Networking, тестами и зафиксированным списком файлов.",
    steps: [
        "Перейди в Sources",
        "Создай папку Networking",
        "Внутри — API.swift и NetworkManager.swift",
        "Вернись в Tests",
        "Создай папку NetworkingTests",
        "В Assets создай папки Icons, Images, Sounds",
        "Добавь NetworkManagerTests.swift",
        "Перейди обратно в корень",
        "Создай manifest.txt",
        "Добавь туда список всех файлов, включая тестовые",
        "Просмотри содержимое manifest.txt",
        "Переименуй manifest.txt в project_files.txt",
        "Создай копию в .config/backup_files.txt",
        "Проверь, что остался оригинал",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd", "mkdir", "touch", "touch_some", "touch_in_dir", "cd_upin", "mkdir_some", "cd_up2", "find", "cat", "mv_rename", "mkdir_p", "cp_file_in_dir", "grep", "ls_grep", "clear", "man"]
)

let mission33 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 3. «Подготовка проекта к локализации»",
    description: "Что получим:\nСозданная структура локализаций для приложения и понимание организации строковых ресурсов.",
    steps: [
        "Перейди в Assets",
        "Создай папку Localization",
        "В ней — папки en.lproj, ru.lproj, zh-Hans.lproj",
        "В каждой — файл Localizable.strings",
        "В en.lproj добавь строку ”hello” = ”Hello!”;",
        "В ru.lproj — ”hello” = ”Привет!”;",
        "В zh-Hans.lproj — ”hello” = ”你好”;",
          "Вернись в Assets",
        "Создай localization_manifest.txt",
        "Добавь туда список языков",
        "Проверь содержимое",
        "Скопируй этот файл в корень проекта",
        "Удали оригинал из Assets",
        "Посмотри содержимое корня",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd", "mkdir", "mkdir_multiple", "touch_some", "echo", "echo_e", "cat", "cp_up2", "ls", "cp", "rm", "cd_up2", "cd", "clear", "man"]
)

let mission34 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 4. «Рефакторинг структуры проекта»",
    description: "Что получим:\nРефакторинг структуры проекта с расширениями и документацией.",
    steps: [
        "Создай новую папку WeatherCore",
        "Перемести в неё Sources и Assets",
        "В WeatherCore создай подпапку Extensions",
        "Добавь туда String+Extension.swift и UIColor+Extension.swift",
        "Вернись в корень",
        "Создай Docs и CHANGELOG.md",
        "Добавь в CHANGELOG дату и текст “Project restructured",
        "Создай папку Build",
        "В ней сделай подпапку Release",
        "Добавь пустой файл build.log",
        "Проверь дерево проекта",
        "Сохрани его в structure_after_refactor.txt",
        "Просмотри файл",
        "Вернись в домашнюю директорию",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "mv", "mv_from_dir", "cd", "touch_some", "touch", "echo_append", "cat", "cd_home", "touch_in_dir", "tree", "tree_in_file", "clear", "man"]
)

let mission35 = Mission(
    taskType: TaskType.createAndStructure,
    title: "Квест 5. «Создание мульти-модульного workspace»",
    description: "Что получим:\nПонимание структуры workspace для крупных iOS-проектов.",
    steps: [
        "Создай папку Workspace",
        "В ней — WeatherApp, MapKitModule, CoreKit, UIComponents",
        "В каждом создай Sources и Tests",
        "В WeatherApp/Sources добавь App.swift",
        "В MapKitModule/Sources — MapManager.swift",
        "В CoreKit/Sources — CoreDataManager.swift",
        "В UIComponents/Sources — ButtonView.swift",
        "Вернись в Workspace",
        "Создай WorkspaceManifest.txt и добавь список всех .swift файлов",
        "Скопируй WorkspaceManifest.txt в CoreKit/Tests",
        "Удали файл из корня",
        "Проверь, что он есть в CoreKit/Tests",
        "Удали пустую папку, если осталась",
        "Вернись в домашнюю директорию",
        "Очисти экран"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["mkdir", "cd", "mkdir_multiple", "mkdir_for", "touch", "touch_in_dir", "find", "cp_file_in_dir", "cp", "rm", "ls_in_dir", "cd_home", "clear", "man"]
)

// MARK: - Профи Блок 2. Работа с файлами и содержимым
let mission36 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 1. «Лаборатория логов»",
    description: "Что получим:\nCоберем, объединии и изучим логи проекта, как это делает настоящий инженер.",
    steps: [
        "Перейди в директорию ~/Developer/Logs",
        "Создай подпапку iOSApp_Logs",
        "Создай в ней три файла: build_log.txt, run_log.txt, crash_log.txt",
        "Запиши в каждый файл по одной строке-тесту",
        "Посмотри, что внутри build_log.txt",
        "Добавь в конец run_log.txt ещё одну строчку",
        "Просмотри первые строки run_log.txt",
        "Просмотри последние строки crash_log.txt",
        "Объедини все логи в файл full_log.txt",
        "Посмотри содержимое full_log.txt",
        "Скопируй этот файл в ~/Desktop",
        "Перейди в ~/Desktop и проверь, что копия на месте",
        "Удали оригинальную папку iOSApp_Logs",
        "Вернись в домашнюю директорию",
        "Очисти терминал и посмотри все шаги логирования(историю)"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_home", "cd_up_some", "mkdir", "touch_some", "echo", "cat", "echo_append", "head_n", "tail_n", "cat_join", "cp", "cp_file_in_dir","ls_l", "rm", "rm_r", "clear", "history", "man"]
)

let mission37 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 2. «Переписка с Xcode»",
    description: "Что получим:\nНавык создания и управления техническими заметками проекта.",
    steps: [
        "Перейди в ~/Developer/Notes",
        "Создай папку XcodeTalks",
        "В ней создай файл build_tips.txt",
        "Добавь туда 3 строки советов",
        "Посмотри содержимое",
        "Создай файл debug_tips.txt и добавь туда советы по дебагу",
        "Объедини оба файла в tips_collection.txt",
        "Посмотри результат объединения",
        "Перемести tips_collection.txt в папку ~/Documents",
        "Проверь, что файл действительно перемещён",
        "Переименуй файл в XcodeMasterTips.txt",
        "Добавь туда ещё одну строчку",
        "Посмотри первые 3 строки",
        "Вернись в домашнюю директорию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "mkdir", "touch", "echo_append", "cat", "cat_join", "mv", "ls_path", "mv_rename", "head_n", "cd_home", "clear", "man"]
)

let mission38 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 3. «Почтовый сервер разработчика»",
    description: "Что получим:\nНавык объединения и обновления данных.“Почтовый ящик” из файлов.",
    steps: [
        "Перейди в ~/Developer/Mailbox",
        "Создай 3 файла: inbox.txt, sent.txt, drafts.txt",
        "Добавь в каждый тестовые сообщения",
        "Проверь содержимое всех трёх",
        "Объедини их в один файл all_mail.txt",
        "Добавь заголовок “Developer Inbox” в начало all_mail.txt",
        "Создай резервную копию этого файла в ~/Documents",
        "Открой all_mail.txt и проверь верхние 5 строк",
        "Добавь ещё одно сообщение в drafts.txt",
        "Снова объедини все три файла в all_mail_v2.txt",
        "Удали старый all_mail.txt",
        "Проверь список файлов(даже скрытых)",
        "Скопируй обновлённую версию на рабочий стол",
        "Вернись в домашнюю директорию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir","touch_some", "echo", "cat", "cat_join", "cp_file_in_dir", "head_n", "echo_append", "rm", "ls_a", "cd_home", "clear", "man"]
)

let mission39 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 4. «Библиотека тестовых данных»",
    description: "Что получим:\nНавык навигации и организации структуры данных.",
    steps: [
        "Перейди в ~/Developer/TestingData",
        "Создай 3 подпапки: UI, Unit, Integration",
        "В каждой создай файл results.txt",
        "Добавь строку “Test passed” в каждый файл",
        "Посмотри содержимое всех файлов",
        "Перейди в UI и создай файл ui_notes.txt",
        "Добавь туда заметку о тестах",
        "Перейди обратно",
        "Скопируй ui_notes.txt в Unit",
        "Переименуй копию в unit_notes.txt",
        "Объедини все *_notes.txt файлы в all_notes.txt",
        "Перенеси all_notes.txt в корень TestingData",
        "Посмотри его содержимое",
        "Удали копии заметок из подпапок",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "mkdir_some", "touch_some", "echo", "cat", "cd", "cd_up", "cp_file_in_dir", "mv_rename", "cat_join", "mv", "rm", "clear", "man"]
)

let mission40 = Mission(
    taskType: TaskType.workWithFiles,
    title: "Квест 5. «История релизов»",
    description: "Что получим:\nНавык обновления, бэкапа и восстановления файлов. Реалистичный changelog проекта.",
    steps: [
        "Перейди в ~/Developer/Releases",
        "Создай файл CHANGELOG.txt",
        "Добавь туда “v1.0 — Initial Release”",
        "Посмотри содержимое",
        "Добавь “v1.1 — Bug fixes”",
        "Посмотри последние строки",
        "Добавь “v2.0 — Major redesign”",
        "Создай резервную копию CHANGELOG_backup.txt",
        "Удали старую версию после копирования",
        "Переименуй backup в CHANGELOG.txt",
        "Добавь новую запись “v2.1 — Hotfix”",
        "Просмотри файл полностью",
        "Скопируй changelog в ~/Desktop/ReleaseNotes.txt",
        "Проверь, что копия существует",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "touch", "cat", "echo", "tail_n", "echo_append", "cp", "rm", "mv_rename", "cp_file_in_dir", "ls_path", "clear", "man"]
)

//MARK: - Профи Блок 3. Диагностика, история и “разработческая чистка”
let mission41 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 1. «Следы сборки»",
    description: "Что получим:\nНавык организации, просмотра и очистки временных сборок. Осознание важности “чистого” окружения.",
    steps: [
        "Перейди в ~/Developer/MyApp",
        "Создай папку Buildst",
        "В ней создай три подпапки: v1, v2, v3",
        "В каждой создай файл build_info.txt",
        "Добавь дату и время сборки",
        "Посмотри содержимое каждого файла",
        "Перейди в v2 и добавь строку “Contains minor updates”",
        "Вернись в Builds",
        "Просмотри список всех файлов",
        "Перенеси v3 в ~/Desktop/OldBuild",
        "Проверь, что в Builds остались только v1 и v2",
        "Скопируй build_info.txt из v2 в корень проекта",
        "Удали старую папку OldBuild с рабочего стола",
        "Вернись в домашнюю директорию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "mkdir", "cd", "mkdir_some", "touch_some", "ls_R", "cat", "echo_append", "cd_home", "ls_path", "mv_rename", "mv", "ls", "cp_file_in_dir", "rm_dir", "clear", "man"]
)

let mission42 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 2. «Операция DerivedData»",
    description: "Что получим:\nПолный навык очистки кэша Xcode. Чистое пространство для новых сборок.",
    steps: [
        "Перейди в ~/Library/Developer/Xcode",
        "Посмотри, есть ли там папка DerivedData",
        "Если есть — открой её",
        "Посмотри её содержимое",
        "Создай файл to_delete_list.txt",
        "Добавь в него имена всех подпапок",
        "Просмотри список",
        "Удали всю папку DerivedData командой с рекурсией",
        "Вернись в ~/Library/Developer/Xcode",
        "Проверь, что DerivedData исчезла",
        "Создай новую пустую папку DerivedData",
        "Добавь в неё файл README.txt с надписью “Clean start”",
        "Проверь содержимое",
        "Вернись в домашнюю директорию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "ls", "touch", "ls_d", "cat", "cd_up", "rm_dir", "mkdir", "echo", "cd_home", "clear", "man"]
)

let mission43 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 3. «Хроники команд»",
    description: "Что получим:\nАрхив своих терминальных действий. Умение работать с перенаправлением вывода и бэкапами.",
    steps: [
        "Перейди в домашнюю директорию",
        "Выполни несколько произвольных команд (например, ls, pwd, echo “test“)",
        "Посмотри историю команд",
        "Создай файл command_history.txt",
        "Перенаправь вывод истории туда",
        "Посмотри файл",
        "Добавь строку “--- End of session ---” в конец",
        "Скопируй файл в ~/Documents/Logs",
        "Перейди в эту папку и проверь копию",
        "Создай резервную версию command_history_backup.txt",
        "Удали оригинал из домашней директории",
        "Открой backup",
        "Добавь туда строку  “Backup created successfully”",
        "Снова выведи содержимое (последние 5 строк)",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "ls", "pwd", "echo", "history", "touch", "redirect", "cat", "echo_append", "mkdir_p", "cp_file_in_dir", "cp", "rm", "tail_n", "clear", "man"]
)

let mission44 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 4. «Сигналы SOS»",
    description: "Что получим:\nПонимание прерывания процессов и контроля за ними. Навык логирования командных сигналов.",
    steps: [
        "В домашней директории введи команду ping 8.8.8.8",
        "Подожди пару секун",
        "Останови процесс",
        "Запусти другую долгую команду — например, yes hello",
        "Прерви её снова",
        "Создай файл signals_log.txt",
        "Запиши туда строку “Прерывание процесса выполнено успешно”",
        "Добавь строку “Изучено сочетание Control + C”",
        "Создай папку ~/Documents/Diagnostics",
        "Перемести туда лог",
        "Перейди в папку Diagnostics",
        "Открой файл",
        "Добавь туда строку “Mission Complete”",
        "Проверь, что она добавилась",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "yes", "touch", "echo", "echo_append", "mkdir_p", "mv", "cat", "clear", "man"]
)

let mission45 = Mission(
    taskType: TaskType.diagnosticAndHistory,
    title: "Квест 5. «Ресурсы под микроскопом»",
    description: "Что получим:\nНавык диагностировать структуру проекта и создать отчёт.",
    steps: [
        "Перейди в ~/Developer/MyBigApp",
        "Посмотри содержимое (включая скрытые файлы)",
        "Перенаправь список файлов в structure_report.txt",
        "Добавь дату в начало файла (echo $(date) | cat - structure_report.txt > temp && mv temp structure_report.txt)",
        "Посмотри отчёт",
        "Скопируй его в ~/Documents/Reports",
        "Перейди туда",
        "Создай ещё один файл report_summary.txt",
        "Добавь туда строку “Отчёт успешно создан”",
        "Просмотри первые строки",
        "Объедини оба отчёта в final_report.txt",
        "Удали исходные structure_report.txt и report_summary.txt",
        "Проверь, что остался только финальный отчёт",
        "Добавь туда строку “Проверено вручную”",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "ls", "ls_a", "echo", "echo_append", "cat", "mv", "redirect", "cp","cp_file_in_dir", "rm", "touch", "head","clear", "man"]
)

//MARK: - Профи Блок 3. Диагностика, история и “разработческая чистка”
let mission46 = Mission(
    taskType: TaskType.likeInReal,
    title: "Квест 1. «Архитектор проекта»",
    description: "Что получим:\nCоздадим структуру iOS-приложения вручную — как Xcode делает это автоматически.",
    steps: [
        "Перейди в ~/Developer",
        "Создай папку WeatherProApp",
        "Перейди внутрь неё",
        "Создай подпапки: Sources, Resources, Tests, Configs",
        "В Sources создай ещё папки Models, Views, ViewModels, Services",
        "В каждой подпапке создай файл README.txt",
        "Добавь в каждый README краткое описание назначения папки",
        "В Resources создай папку Assets и файл AppIcon.txt",
        "В Configs создай файл BuildSettings.txt и запиши туда SDK = iOS 18",
        "Перейди в корень проекта и выведи список всех подпапок рекурсивно",
        "Перенаправь вывод в файл structure_map.txt",
        "Просмотри первые 10 строк отчёта",
        "Скопируй отчёт в ~/Documents/Reports",
        "Вернись в домашнюю директорию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "mkdir", "cd", "mkdir_some", "mkdir_multiple", "touch_some", "echo", "cd_up", "tree", "tree_in_file", "redirect", "head", "mkdir_p", "cd_home", "clear", "man"]
)

let mission47 = Mission(
    taskType: TaskType.likeInReal,
    title: "Квест 2. «Миграция проекта»",
    description: "Что получим:\nПеренесем проект в новую директорию и сохраним структуру без потерь.",
    steps: [
        "Перейди в ~/Developer/WeatherProApp",
        "Убедись, что все подпапки на месте",
        "Создай новую папку ~/Developer/WeatherProApp_v2",
        "Скопируй весь проект в новую директорию",
        "Перейди в WeatherProApp_v2",
        "Создай там папку Archive",
        "Перемести в неё Configs и Tests",
        "Добавь в Archive/README.txt строку “Archived configs and tests”",
        "Проверь, что в корне проекта остались только Sources и Resources",
        "В Sources создай файл Version.txt с записью v2.0",
        "Добавь дату создания через echo $(date) >> Version.txt",
        "Посмотри файл",
        "Перенаправь список файлов в summary.txt",
        "Скопируй отчёт в ~/Documents/Migrations",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "ls", "mkdir", "mkdir_multiple", "cp_dir", "cp_files_in_dir", "mv_from_dir", "cd", "echo", "echo_append", "cat", "cd_up", "redirect", "mkdir_p", "clear", "man"]
)

let mission48 = Mission(
    taskType: TaskType.likeInReal,
    title: "Квест 3. «Контроль версий без Git»",
    description: "Что получим:\nПонимание, как отслеживать изменения вручную, как создать мини-систему версионирования(аналогия с Git).",
    steps: [
        "Перейди в ~/Developer/WeatherProApp_v2/Sources",
        "Создай файл MainViewModel.swift",
        "Добавь в него строку // Version 1.0",
        "Скопируй файл в MainViewModel_v1.swift",
        "Измени оригинал: добавь строку // Added update logic",
        "Скопируй файл как MainViewModel_v2.swift",
        "Создай папку Versions",
        "Перемести туда обе версии _v1 и _v2",
        "В Versions создай README.txt с описанием версий",
        "Перейди в корень проекта и создай version_log.txt",
        "Добавь туда список всех версий",
        "Посмотри лог",
        "Скопируй его в ~/Documents/VersionControl",
        "Проверь копию",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "touch", "echo", "cp", "mkdir", "mv", "cat", "ls", "clear", "man"]
)

let mission49 = Mission(
    taskType: TaskType.likeInReal,
    title: "Квест 4. «Переименование всего проекта»",
    description: "Что получим:\nОтработка массового переименования и управления структурой.",
    steps: [
        "Перейди в ~/Developer",
        "Найди папку WeatherProApp_v2",
        "Переименуй её в WeatherElite",
        "Перейди внутрь",
        "Переименуй Sources в AppCode",
        "Переименуй Resources в AssetsBundle",
        "Создай файл project_meta.txt",
        "Запиши туда старое и новое название проекта",
        "Добавь дату изменения",
        "Скопируй project_meta.txt в ~/Documents/Archives",
        "Удали пустую папку Archive, если осталась",
        "Посмотри текущую структуру",
        "Перенаправь вывод в structure_after_rename.txt",
        "Перемести этот отчёт в ~/Documents/Reports",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "mv", "cd", "touch", "echo", "echo_rename", "rm_dir", "cp", "ls_R", "clear", "man"]
)

let mission50 = Mission(
    taskType: TaskType.likeInReal,
    title: "Квест 5. «Автоматизация рутины»",
    description: "Что получим:\nСоздим сценарий “чистого старта” проекта вручную, как будто это pre-build скрипт(аналогия с CI-скриптами, которые выполняют “чистку” и отчёты).",
    steps: [
        "Перейди в ~/Developer/WeatherElite",
        "Создай файл reset_project.txt",
        "Добавь туда строки:\n“Очистить DerivedData”\n“Создать временную папку TempBuilds”\n“Удалить старые отчёты”",
        "Создай папку Scripts",
        "Перемести туда reset_project.txt",
        "Создай файл run_log.txt в Scripts",
        "Запиши туда текущую дату запуска",
        "Добавь строку “Сценарий выполнен успешно”",
        "Перемести run_log.txt в ~/Documents/Logs",
        "Перейди в ~/Documents/Logs и проверь, что лог на месте",
        "Вернись обратно в WeatherElite",
        "Создай файл LAST_RUN.txt с датой выполнения",
        "Посмотри все текстовые файлы в проекте",
        "Объедини их в final_state.txt",
        "Очисти терминал"
    ],
    completed: [false, false, false, false, false,false, false, false, false, false,false, false, false, false, false],
    cheatSheetCommands: ["cd_in_dir", "echo_e", "mkdir", "mv", "touch", "echo_rename", "mkdir_p", "ls", "cd", "find", "clear", "man"]
)
