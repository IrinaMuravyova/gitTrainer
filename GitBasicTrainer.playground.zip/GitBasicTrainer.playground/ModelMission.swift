import Foundation

// MARK: - Модель миссии
struct Mission: Identifiable, Equatable {
    let id = UUID()
    let taskType: TaskType
    let title: String
    let description: String
    let steps: [String]
    var completed: [Bool]
    let cheatSheetCommands: [String] 
    
    mutating func completeStep(_ index: Int) {
        guard index >= 0 && index < steps.count else { return }
        completed[index] = true
    }
}

// MARK: - Вычисляемые свойства для Mission
extension Mission {
    var completedSteps: Int {
        completed.filter { $0 }.count
    }
    
    var progress: Double {
        Double(completedSteps) / Double(steps.count)
    }
    
    var isFullyCompleted: Bool {
        completed.allSatisfy { $0 }
    }
}


// MARK: - Функции для создания миссий каждого уровня
func createBeginnerMissions() -> [Mission] {
    return [mission1, mission2, mission3, mission4, mission5, 
            mission6, mission7, mission8, mission9, mission10,
            mission11, mission12, mission13, mission14, mission15]
}

func createIntermediateMissions() -> [Mission] {
    return [mission16, mission17, mission18, mission19, mission20, 
            mission21, mission22, mission23, mission24, mission25,
            mission26, mission27, mission28, mission29, mission30]
}

func createProfessionalMissions() -> [Mission] {
    return [mission31, mission32, mission33, mission34, mission35, 
            mission36, mission37, mission38, mission39, mission40,
            mission41, mission42, mission43, mission44, mission45,
            mission46, mission47, mission48, mission49, mission50]
}
