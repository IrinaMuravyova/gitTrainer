import Foundation

// MARK: - Модель для хранения состояния уровня
struct LevelState {
    var missions: [Mission]
    var selectedMissionIndex: Int
    var log: [String]
    
    var currentMission: Mission {
        missions[selectedMissionIndex]
    }
}
