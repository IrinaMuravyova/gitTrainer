import SwiftUI

struct ContentView: View {
    @StateObject private var levelManager = LevelStateManager()
    
    var body: some View {
        NavigationView {
            // Левая панель - список уровней и миссий
            SidebarView(levelManager: levelManager)
            
            // Правая панель - детали выбранной миссии
            MissionDetailView(
                mission: levelManager.currentState.currentMission,
                log: Binding(
                    get: { levelManager.currentState.log },
                    set: { newLog in
                        levelManager.levelStates[levelManager.selectedLevel]?.log = newLog
                    }
                ),
                onMissionUpdate: { updatedMission in
                    levelManager.updateMission(updatedMission)
                }
            )
        }
        .navigationTitle("\(IconConstants.title) \(TextConstants.appTitle) - \(levelManager.selectedLevel.rawValue)")
    }
}

struct SidebarView: View {
    @ObservedObject var levelManager: LevelStateManager
    
    private var missionsByType: [TaskType: [Mission]] {
        Dictionary(grouping: levelManager.currentState.missions) { $0.taskType }
    }
    
    private var taskTypesInOrder: [TaskType] {
        TaskType.allCases.filter { missionsByType[$0] != nil }
    } 
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.defaultSpacing) {
            Text(TextConstants.appTitle)
                .font(FontConstants.title2)
                .bold()
                .padding(.horizontal)

            Picker(TextConstants.levelPickerTitle, selection: $levelManager.selectedLevel) {
                ForEach(Level.allCases) { level in
                    Text(level.rawValue).tag(level)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.horizontal)
            
            Text(TextConstants.missionsTitle)
                .font(FontConstants.headline)
                .padding(.horizontal)
            
            ScrollView {
                LazyVStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
                
                    ForEach(taskTypesInOrder, id: \.self) { taskType in
                        // Заголовок с названием типа задач
                        VStack(alignment: .leading, spacing: 4) {
                            Text(taskType.rawValue)
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.secondaryMain)
                                .padding(.horizontal, 8)
                                .padding(.top, 8)
                            
                            // Миссии этого типа
                            ForEach(Array(missionsByType[taskType]!.enumerated()), id: \.element.id) { index, mission in
                                let globalIndex = levelManager.currentState.missions.firstIndex { $0.id == mission.id } ?? 0
                                
                                MissionRowView(
                                    mission: mission,
                                    isSelected: levelManager.currentState.selectedMissionIndex == globalIndex,
                                    onTap: {
                                        levelManager.updateSelectedMissionIndex(globalIndex)
                                    }
                                )
                            }
                        }
                    }
                }
                .padding(.horizontal)
            }
        }
        .frame(width: LayoutConstants.sidebarWidth)
        .background(ColorConstants.systemBackground)
    }
}
