import SwiftUI

struct MissionRowView: View {
    let mission: Mission
    let isSelected: Bool
    var onTap: (() -> Void)? = nil
    
    private var progressValue: Double {
        let completed = mission.completed.filter { $0 }.count
        return Double(completed) / Double(mission.steps.count)
    }
    
    private var completedSteps: Int {
        mission.completed.filter { $0 }.count
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.tinySpacing) {
            Text(mission.title)
                .font(FontConstants.headline)
                .foregroundColor(isSelected ? ColorConstants.primaryBlue : Color.primary)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
            
            // Прогресс миссии
            VStack(alignment: .leading, spacing: LayoutConstants.microSpacing) {
                HStack {
                    SwiftUI.ProgressView(value: progressValue)
                        .progressViewStyle(LinearProgressViewStyle())
                    .tint(isSelected ? ColorConstants.primaryBlue : ColorConstants.primaryGreen)
                    
                    Text(String(format: TextConstants.stepsCountFormat, completedSteps, mission.steps.count))
                        .font(FontConstants.caption)
                        .foregroundColor(ColorConstants.primaryGray)
                }
                
                Text(String(format: TextConstants.percentageFormat, Int(progressValue * 100)))
                    .font(FontConstants.caption2)
                    .foregroundColor(ColorConstants.secondaryGray)
            }
        }
        .padding()
        .background(
             RoundedRectangle(cornerRadius: LayoutConstants.cornerRadius)
                .fill(isSelected ? 
                      ColorConstants.primaryBlue.opacity(ColorConstants.lowOpacity) : 
                        ColorConstants.cellBackground)
                .shadow(color: ColorConstants.primaryGray.opacity(0.2), 
                        radius: 2, x: 0, y: 1)
        )
        .overlay(
            RoundedRectangle(cornerRadius: LayoutConstants.cornerRadius)
                .stroke(isSelected ? ColorConstants.primaryBlue : Color.clear, 
                        lineWidth: LayoutConstants.borderWidth)
        )
        .onTapGesture {
            onTap?()
        }
    }
}
