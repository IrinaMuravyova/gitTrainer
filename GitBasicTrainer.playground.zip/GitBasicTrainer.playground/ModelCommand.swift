import SwiftUI

// MARK: - Структура для команд шпаргалки
struct CommandInfo: Identifiable, Equatable {
    let id = UUID()
    let command: String
    let description: String
    
    static func == (lhs: CommandInfo, rhs: CommandInfo) -> Bool {
        lhs.id == rhs.id &&
        lhs.command == rhs.command &&
        lhs.description == rhs.description
    }
}
