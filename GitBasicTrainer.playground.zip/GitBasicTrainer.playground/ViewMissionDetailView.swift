import SwiftUI

struct MissionDetailView: View {
    let mission: Mission
    @Binding var log: [String]
    let onMissionUpdate: (Mission) -> Void
    
    @State private var localMission: Mission
    @State private var isCheatSheetExpanded = false
    
    init(mission: Mission, log: Binding<[String]>, onMissionUpdate: @escaping (Mission) -> Void) {
        self.mission = mission
        self._log = log
        self.onMissionUpdate = onMissionUpdate
        self._localMission = State(initialValue: mission)
    }
    
    private var cheatSheetCommands: [CommandInfo] {
        CommandConstants.getCommands(for: localMission.cheatSheetCommands)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LayoutConstants.defaultSpacing) {
                MissionHeaderView(mission: localMission)
                
                HStack(alignment: .top, spacing: LayoutConstants.defaultSpacing) {
                    VStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
                        MissionProgressView(mission: localMission) 
                        
                        StepsListView(
                            mission: $localMission,
                            onStepToggle: toggleStep
                        )
                    }
                    
                    // Правая часть - шпаргалка
                    CheatSheetView(
                        isExpanded: $isCheatSheetExpanded,
                        commands: cheatSheetCommands
                    )
                    .frame(width: LayoutConstants.cheatSheetWidth)
                }
                
                LogView(log: $log)
                Spacer()
            }
            .padding()
        }
        .onChange(of: mission) { newMission in
            localMission = newMission
        }
    }
    
    private func toggleStep(_ index: Int) {
        localMission.completed[index].toggle()
        onMissionUpdate(localMission)
        
        // Логирование
        let stepStatus = localMission.completed[index] ? 
        String(format: TextConstants.stepCompletedFormat, index+1) : 
        String(format: TextConstants.stepUncompletedFormat, index+1)
        
        let progressText = String(format: TextConstants.progressFormat, 
                                  localMission.completedSteps, 
                                  localMission.steps.count)
        
        let logEntry = String(format: TextConstants.missionLogFormat, 
                              localMission.title, stepStatus, progressText)
        log.append(logEntry)
        
        if localMission.isFullyCompleted {
            log.append("\(IconConstants.missionCompleted) \(TextConstants.missionCompleted)")
        }
    }
}

// MARK: - Subviews
struct MissionHeaderView: View {
    let mission: Mission
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
            Text(mission.title)
                 .font(FontConstants.title)
                .bold()
            
            Text(mission.description)
                .font(FontConstants.title3)
                .foregroundColor(ColorConstants.secondaryGray)
        }
    }
}

struct MissionProgressView: View {
    let mission: Mission
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.tinySpacing) {
            HStack {
                Text(TextConstants.missionProgress)
                    .font(FontConstants.headline)
                Spacer()
                Text(String(format: TextConstants.stepsCountFormat, 
                            mission.completedSteps, 
                            mission.steps.count))
                .font(FontConstants.caption)
                .foregroundColor(ColorConstants.secondaryGray)
            }
            
            SwiftUI.ProgressView(value: mission.progress)
                .progressViewStyle(LinearProgressViewStyle())
        }
        .padding()
        .background(ColorConstants.primaryBlue.opacity(ColorConstants.lowOpacity))
        .cornerRadius(LayoutConstants.cornerRadius)
    }
}

struct StepsListView: View {
    @Binding var mission: Mission
    let onStepToggle: (Int) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.defaultSpacing) {
            Text(TextConstants.stepsTitle)
                .font(FontConstants.title2)
                .bold()
            
            LazyVStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
                ForEach(mission.steps.indices, id: \.self) { index in
                    StepRowView(
                        step: mission.steps[index],
                        isCompleted: mission.completed[index],
                        onToggle: { onStepToggle(index) }
                    )
                }
            }
        }
    }
}

struct StepRowView: View {
    let step: String
    let isCompleted: Bool
    let onToggle: () -> Void
    
    var body: some View {
        HStack(alignment: .top, spacing: LayoutConstants.defaultSpacing) {
            Image(systemName: isCompleted ? IconConstants.checkmarkCircleFill : IconConstants.circle)
                .font(FontConstants.title2)
                .foregroundColor(isCompleted ? ColorConstants.primaryGreen : ColorConstants.primaryGray)

            Text(step)
                .strikethrough(isCompleted, color: ColorConstants.primaryGreen)
                .foregroundColor(isCompleted ? ColorConstants.secondaryGray : ColorConstants.primaryMain)
                .multilineTextAlignment(.leading)
            
            Spacer()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: LayoutConstants.smallCornerRadius)
                .fill(isCompleted ? 
                      ColorConstants.primaryGreen.opacity(ColorConstants.lowOpacity) : 
                    ColorConstants.primaryGray.opacity(ColorConstants.lowOpacity))
        )
        .contentShape(Rectangle())
        .onTapGesture(perform: onToggle)
    }
}

struct CheatSheetView: View {
    @Binding var isExpanded: Bool
    let commands: [CommandInfo]
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
            HStack {
                Text(TextConstants.cheatSheetTitle)
                    .font(FontConstants.title2)
                    .bold()
                
                Spacer()
                
                Image(systemName: isExpanded ? IconConstants.chevronDown : IconConstants.chevronRight)
                    .foregroundColor(ColorConstants.primaryBlue)
                    .font(FontConstants.headline)
            }
            .contentShape(Rectangle())
            .onTapGesture {
                withAnimation(AnimationConstants.easeInOut) {
                    isExpanded.toggle()
                }
            }
            
            Text(TextConstants.cheatSheetHint)
                .font(FontConstants.caption)
                .foregroundColor(ColorConstants.primaryOrange)
                .italic()
                .multilineTextAlignment(.leading)
            
            if isExpanded {
                LazyVStack(alignment: .leading, spacing: LayoutConstants.tinySpacing) {
                    ForEach(commands) { commandInfo in
                        CommandRowView(commandInfo: commandInfo)
                    }
                }
                .transition(AnimationConstants.opacityCombinedWithScale)
            }
        }
        .padding()
        .background(ColorConstants.primaryOrange.opacity(ColorConstants.veryLowOpacity))
        .cornerRadius(LayoutConstants.mediumCornerRadius)
        .overlay(
            RoundedRectangle(cornerRadius: LayoutConstants.mediumCornerRadius)
                .stroke(ColorConstants.primaryOrange.opacity(ColorConstants.mediumOpacity), 
                        lineWidth: LayoutConstants.thinBorderWidth)
        )
    }
}

struct CommandRowView: View {
    let commandInfo: CommandInfo
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.microSpacing) {
            HStack(alignment: .top, spacing: LayoutConstants.tinySpacing) {
                Text(IconConstants.dollarSign)
                    .font(FontConstants.monospacedBody)
                    .foregroundColor(ColorConstants.primaryGreen)
                    .bold()
                
                Text(commandInfo.command)
                 .font(FontConstants.monospacedBody)
                 .foregroundColor(ColorConstants.primaryMain)
                    .textSelection(.enabled)
            }
            
            Text(commandInfo.description)
                .font(FontConstants.caption)
                .foregroundColor(ColorConstants.secondaryGray)
                .multilineTextAlignment(.leading)
                .padding(.leading, 20)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, LayoutConstants.tinySpacing)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(ColorConstants.primaryGray.opacity(ColorConstants.ultraLowOpacity))
        .cornerRadius(6)
    }
}

struct LogView: View {
    @Binding var log: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: LayoutConstants.smallSpacing) {
            Text(TextConstants.logTitle)
                .font(FontConstants.title2)
                .bold()
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: LayoutConstants.tinySpacing) {
                        ForEach(log.reversed(), id: \.self) { logEntry in
                            Text(logEntry)
                                .font(FontConstants.monospaced)
                                .foregroundColor(ColorConstants.primaryBlue)
                                .padding(.vertical, LayoutConstants.microSpacing)
                                .padding(.horizontal, LayoutConstants.tinySpacing)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            .background(ColorConstants.primaryBlue.opacity(ColorConstants.lowOpacity))
                                .cornerRadius(6)
                        }
                    }
                }
                .frame(height: LayoutConstants.logHeight)
                .onChange(of: log.count) { _ in
                    if let lastId = log.last {
                        proxy.scrollTo(lastId, anchor: .bottom)
                    }
                }
            }
        }
    }
}
