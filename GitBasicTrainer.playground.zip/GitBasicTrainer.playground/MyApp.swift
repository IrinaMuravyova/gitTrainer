import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


// Нажми ▶️ вверху экрана, чтобы запустить
