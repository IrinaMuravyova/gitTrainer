import SwiftUI

@MainActor
class LevelStateManager: ObservableObject {
    @Published var levelStates: [Level: LevelState] = [:]
    @Published var selectedLevel: Level = .beginner
    
    init() {
        initializeLevelStates()
    }
    
    // MARK: - Public Methods
    var currentState: LevelState {
        levelStates[selectedLevel] ?? createInitialState(for: selectedLevel)
    }
    
    func updateSelectedMissionIndex(_ index: Int) {
        guard levelStates[selectedLevel]?.missions.indices.contains(index) == true else { return }
        levelStates[selectedLevel]?.selectedMissionIndex = index
    }
    
    func updateMission(_ updatedMission: Mission) {
        guard let index = levelStates[selectedLevel]?.missions.firstIndex(where: { $0.id == updatedMission.id }) else {
            print("Mission not found: \(updatedMission.id)")
            return
        }
        levelStates[selectedLevel]?.missions[index] = updatedMission
    }
    
    func addLogEntry(_ entry: String) {
        levelStates[selectedLevel]?.log.append(entry)
    }
    
    func resetLevel(_ level: Level) {
        levelStates[level] = createInitialState(for: level)
    }
    
    // MARK: - Private Methods
    private func initializeLevelStates() {
        Level.allCases.forEach { level in
            if levelStates[level] == nil {
                levelStates[level] = createInitialState(for: level)
            }
        }
    }
    
    private func createInitialState(for level: Level) -> LevelState {
        let missions: [Mission]
        switch level {
        case .beginner:
            missions = createBeginnerMissions()
        case .intermediate:
            missions = createIntermediateMissions()
        case .professional:
            missions = createProfessionalMissions()
        }
        
        return LevelState(
            missions: missions,
            selectedMissionIndex: 0,
            log: []
        )
    }
}
