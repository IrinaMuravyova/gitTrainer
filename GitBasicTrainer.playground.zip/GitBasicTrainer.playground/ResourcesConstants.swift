import SwiftUI

enum Level: String, CaseIterable, Identifiable {
    case beginner = "🟢 Новичок"
    case intermediate = "🟡 Продвинутый" 
    case professional = "🔴 Профи"
    
    var id: String { self.rawValue }
}

enum TaskType: String, CaseIterable, Identifiable {
    case createAndStructure = "Создаем и наводим порядок в проекте"
    case workWithFiles = "Работа с файлами и содержимым"
    case diagnosticAndHistory = "Диагностика, история и разработческая чистка"
    case likeInReal = "Эти квесты моделируют реальные задачи iOS-разработчика"
    
    var id: String { self.rawValue }
}

// MARK: - Текстовые константы
struct TextConstants {
    // Заголовки и лейблы
    static let appTitle = "Терминальные квесты"
    static let missionsTitle = "Миссии:"
    static let levelPickerTitle = "Уровень сложности"
    static let missionProgress = "Прогресс миссии:"
    static let stepsTitle = "Шаги выполнения:"
    static let cheatSheetTitle = "Шпаргалка"
    static let logTitle = "История выполнения:"
    
    // Сообщения и подсказки
    static let cheatSheetHint = "Рекомендуется пользоваться подсказкой только после того как вы попробовали выполнить задание самостоятельно"
    static let missionCompleted = "Миссия выполнена полностью!"
    static let stepCompletedFormat = "✅ шаг %d"
    static let stepUncompletedFormat = "❌ шаг %d"
    static let progressFormat = "Прогресс: %d/%d"
    
    // Форматы
    static let missionLogFormat = "%@: %@ %@"
    static let stepsCountFormat = "%d/%d шагов"
    static let percentageFormat = "%d%% выполнено"
}

// MARK: - Визуальные константы
struct LayoutConstants {
    // Размеры
    static let sidebarWidth: CGFloat = 300
    static let logHeight: CGFloat = 200
    static let cheatSheetWidth: CGFloat = 300
    
    // Отступы
    static let defaultSpacing: CGFloat = 16
    static let smallSpacing: CGFloat = 12
    static let tinySpacing: CGFloat = 8
    static let microSpacing: CGFloat = 4
    
    // Радиусы скругления
    static let cornerRadius: CGFloat = 10
    static let smallCornerRadius: CGFloat = 8
    static let mediumCornerRadius: CGFloat = 12
    static let largeCornerRadius: CGFloat = 12
    
    // Толщины линий
    static let borderWidth: CGFloat = 2
    static let thinBorderWidth: CGFloat = 1
}

// MARK: - Цвета
struct ColorConstants {
    // Основные цвета
    static let primaryBlue = Color.blue
    static let primaryGreen = Color.green
    static let primaryOrange = Color.orange
    static let primaryGray = Color.gray
    static let secondaryGray = Color(uiColor: .systemGray)
    static let primaryMain = Color.primary
    static let secondaryMain = Color.secondary
    
    // Прозрачности
    static let lowOpacity: Double = 0.1
    static let mediumOpacity: Double = 0.3
    static let veryLowOpacity: Double = 0.05
    static let ultraLowOpacity: Double = 0.08
    
    // Системные цвета
    static let systemBackground = Color(UIColor.systemBackground)
    static let cellBackground = Color(UIColor.secondarySystemBackground)
}

// MARK: - Иконки
struct IconConstants {
    // SF Symbols
    static let chevronDown = "chevron.down"
    static let chevronRight = "chevron.right"
    static let checkmarkCircleFill = "checkmark.circle.fill"
    static let circle = "circle"
    static let dollarSign = "$"
    
    // Эмодзи
    static let missionCompleted = "🎉"
    static let stepCompleted = "✅"
    static let stepUncompleted = "❌"
    static let title = "🕹"
    
    // Уровни сложности
    static let beginnerLevel = "🟢"
    static let intermediateLevel = "🟡"
    static let professionalLevel = "🔴"
}

// MARK: - Шрифты
struct FontConstants {
    static let title = Font.largeTitle
    static let title2 = Font.title2
    static let title3 = Font.title3
    static let headline = Font.headline
    static let body = Font.body
    static let caption = Font.caption
    static let caption2 = Font.caption2
    static let monospacedBody = Font.system(.body, design: .monospaced)
    static let monospaced = Font.system(.body, design: .monospaced)
}

// MARK: - Анимации
struct AnimationConstants {
    static let easeInOut = Animation.easeInOut(duration: 0.3)
    static let opacityCombinedWithScale = AnyTransition.opacity.combined(with: .scale(scale: 0.95))
}

// MARK: - Команды терминала
struct CommandConstants {
    static let allCommands: [String: CommandInfo] = [        
        // Базовые команды
        "pwd": CommandInfo(command: "pwd", description: "Показать текущую директорию"),
        "ls": CommandInfo(command: "ls", description: "Показать файлы и папки в текущей директории"),
        "ls_in_dir": CommandInfo(command: "ls <папка>/<папка>/", description: "Проверить, что файл есть в конечной папке"),
        "ls_path": CommandInfo(command: "ls ~/<папка>/<папка>/<папка>/<папка>", description: "Проверить, существует ли путь."),
        "ls_a": CommandInfo(command: "ls -a", description: "Показать все файлы (включая скрытые)"),
        "ls_d": CommandInfo(command: "ls -d */", description: "Показать все папки екущей директории (без файлов)"),
        "ls_l": CommandInfo(command: "ls -l", description: "Подробный список файлов с правами доступа"),
        "ls_la": CommandInfo(command: "ls -la", description: "Подробный список всех файлов"),
        "ls_save": CommandInfo(command: "ls <папка> > <папка>/<файл>", description: "Сохранить список файлов в отдельном документе"),
        "cd": CommandInfo(command: "cd <папка>", description: "Перейти в указанную папку"),
        "cd_up": CommandInfo(command: "cd ..", description: "Перейти на уровень выше"),
        "cd_up2": CommandInfo(command: "cd ../..", description: "Перейти на 2 уровеня выше"),
        "cd_upin": CommandInfo(command: "cd ../<папка>", description: "Перейти на уровень выше в указанную папку"),
        "cd_in_some": CommandInfo(command: "cd <папка>/<папка>/<папка>/<папка>", description: "Перейти сразу в указанную папку вконце цепочки."),
        "cd_up_some": CommandInfo(command: "cd ../../../..", description: "Сколько таких блоков (..), настолько папок вверх перпейдет."),
        "cd_home": CommandInfo(command: "cd ~", description: "Перейти в домашнюю директорию"),
        "cd_in_dir": CommandInfo(command: "cd ~/<папка>/<папка>", description: "Перейти в папку"),
        "mkdir": CommandInfo(command: "mkdir <имя>", description: "Создать новую папку"),
        "mkdir_some": CommandInfo(command: "mkdir <имя> <имя> <имя>", description: "Создать сразу несколько папок."),
        "mkdir_hide": CommandInfo(command: "mkdir .<имя>", description: "Создать скрытую папку"),
        "mkdir_multiple": CommandInfo(command: "mkdir -p <папка>/<папка>/<папка>/<папка>", description: "Создать вложенную структуру папок сразу, даже если промежуточные папки отсутствуют."),
        "mkdir_p": CommandInfo(command: "mkdir -p path/to/folder", description: "Создать несколько вложенных папок"),
        "mkdir_for": CommandInfo(command: "for <name_of_variable> in <папка> <папка> <папка> <папка>; do\nmkdir $<name_of_variable>/<новая папка 1> $<name_of_variable>/<новая папка 2>\ndone", description: "Создаёт одинаковую структуру в нескольких папках сразу"),
        "man": CommandInfo(command: "man <команда>", description: "Открыть руководство по команде.\nВ справке можно посмотреть все параметры команды\n#    Навигация: стрелки вверх/вниз для пролистывания, /keyword для поиска\n#    Например, /options и Enter для поиска параметров\n#    Нажмите q для выхода из справки"),
        "touch": CommandInfo(command: "touch <файл>", description: "Создать новый файл"),
        "touch_some": CommandInfo(command: "touch <файл1> <файл2> <файл3>", description: "Создать несколько файлов за раз"),
        "touch_in_dir": CommandInfo(command: "touch <папка>/<файл>", description: "Создать новый файл внутри папки"),
        "cat": CommandInfo(command: "cat <файл>", description: "Показать содержимое файла"),
        "cat_join": CommandInfo(command: "cat <файл> <файл> <файл> > <файл>", description: "Объединить содержимое файлов в один"),
        "clear": CommandInfo(command: "clear", description: "Очистить экран терминала"),
        "history": CommandInfo(command: "history", description: "Посмотреть историю выполненных команд"),
        "yes": CommandInfo(command: "yes <text>", description: "Запустить бесконечный вывод текста <text>"),
        
        // Команды для работы с файлами
        "echo": CommandInfo(command: "echo 'текст' > файл.txt", description: "Записать текст в файл"),
        "echo_append": CommandInfo(command: "echo 'текст' >> файл.txt", description: "Добавить текст в конец файла"),
        "echo_e": CommandInfo(command: "echo -e 'текст через \n' > <файл>", description: "Позволяет добавить несколько строк через \n."),
        "head": CommandInfo(command: "head <файл>", description: "Показать первые 10 строк файла"),
        "head_n": CommandInfo(command: "head -n 5 <файл>", description: "Показать первые 5 строк файла"),
        "tail": CommandInfo(command: "tail <файл>", description: "Показать последние 10 строк файла"),
        "tail_n": CommandInfo(command: "tail -n 5 <файл>", description: "Показать последние 5 строк файла"),
        "cat_combine": CommandInfo(command: "cat file1 file2 > combined.txt", description: "Объединить несколько файлов в один"),
        
        // Команды для управления файлами
        "cp": CommandInfo(command: "cp <исходный> <копия>", description: "Создать копию файла"),
        "cp_up2": CommandInfo(command: "cp <файл> ../../", description: "Копировать файл в папку на два уровня выше"),
        "cp_dir": CommandInfo(command: "cp -R <папка> <копия>", description: "Скопировать папку рекурсивно"),
        "cp_file_in_dir": CommandInfo(command: "cp <файл1> <папка>/<файл2>", description: "Создать копию файла в конкретной папке"),
        "cp_files_in_dir": CommandInfo(command: "cp -R <папка1>/* <папка2>", description: "Копирует все файлы только из текущего уровня папки1 в папку2.\nЕсли внутри папки1 есть вложенные папки, они не будут скопированы, их содержимое игнорируется."),
        "diff": CommandInfo(command: "diff <файл> <файл>", description: "Проверить, что файлы совпадают"),
        "mv": CommandInfo(command: "mv <файл> <папка>", description: "Переместить файл в папку"),
        "mv_rename": CommandInfo(command: "mv <старое_имя> <новое_имя>", description: "Переименовать файл"),
        "mv_from_dir": CommandInfo(command: "mv <папка>/<файл> <папка>/", description: "Переместить файл из папки в папку"),
        "rm_files": CommandInfo(command: "rv <папка>/*", description: "Удалить оригинальные файлы из папки."),
        "rm": CommandInfo(command: "rm <файл>", description: "Удалить файл"),
        "rm_path": CommandInfo(command: "rm -r ~/<папка>/<папка>/<папка>/<папка>", description: "Удалить папку целиком, если она существует."),
        "rm_r": CommandInfo(command: "rm -r <файл>", description: "(recursive)Рекурсивно удалить папку и всё её содержимое. Если файл/папка защищёны от записи или нет прав на удаление, то терминал спросит подтверждение."),
        "rm_dir": CommandInfo(command: "rm -rf <папка>", description: "(recursive force) Удалить папку и всё её содержимое. Удаляет всё без предупреждений. Не спрашивает подтверждений, не останавливается на ошибках."),
        
        // Команды для поиска и информации
        "ls_R": CommandInfo(command: "ls -R", description: "Рекурсивно показать структуру папок"),
        "ls_grep": CommandInfo(command: "ls | grep <файл>", description: "Проверяет наличие конкретного файла в текущей директории."),
        "find": CommandInfo(command: "find . -name '*.txt'", description: "Найти все txt файлы"),
        "grep": CommandInfo(command: "grep 'текст' <файл>", description: "Найти текст в файле"),
        "print_com_number": CommandInfo(command: "history | grep <команда> ", description: "Найти все команды, содержащие <команда>, и показать их номера."),
        "repeat_com": CommandInfo(command: "!<номер> ", description: "Повторить команду с номером <номер> из истории"),
        "tree": CommandInfo(command: "tree", description: "Проверить дерево проекта"),
        "tree_in_file": CommandInfo(command: "tree > <файл>", description: "Сохранить дерево проекта в <файл>"),
        
        // Команды для перенаправления вывода
        "redirect": CommandInfo(command: "ls > список.txt", description: "Сохранить вывод команды в файл"),
        "append": CommandInfo(command: "ls >> список.txt", description: "Добавить вывод команды в конец файла"),
        
        // Команды для навигацию по командной строке и прерывания потока
        "сontrol_A": CommandInfo(command: "", description: "Перейти в начало командной строки: Ctrl + A"),
        "сontrol_E": CommandInfo(command: "", description: "Перейти в конец командной строки: Ctrl + E"),
        "сontrol_C": CommandInfo(command: "", description: "Прерывать выполнение команды в терминале: Ctrl + С")
    ]
    
    static func getCommands(for commandKeys: [String]) -> [CommandInfo] {
        return commandKeys.compactMap { allCommands[$0] }
    }
}
